%% CALCULO PARA STEP

clc

t_total_STEP = out.flc_step.time;
Vel_real_total_STEP = out.flc_step.signals(2).values;

u_total_STEP = out.flc_step.signals(1).values;

figure(1)
plot(t_total_STEP,u_total_STEP,'g')
hold on
plot( t_total_STEP, Vel_real_total_STEP,'b')
title('FLC Degrau');
xlabel('t (s)');
ylabel('x (mm)');
legend('Desejado', 'Real')
hold off



% % Assuming vdes is the input and vr is the output
% input_signal_STEP = double(u_total_STEP);
% output_signal_STEP = double(Vel_real_total_STEP);
% 
% % Transpose the input and output signals
% input_signal_STEP = input_signal_STEP';
% output_signal_STEP = output_signal_STEP';
% 
% % Create iddata object
% data_STEP = iddata(output_signal_STEP, input_signal_STEP);
% 
% 
% real_STEP = tfest(data_STEP, 2, 2); 
% 
% % Display the estimated transfer function
% disp('Estimated Transfer Function:');
% disp(real_STEP);
% 
% 
% figure(2)
% compare(data_STEP, real_STEP);
% 
% sys_STEP=tf(real_STEP);
%% CALCULO PARA SENO

clc

t_total_SENO = out.flc_sin.time;
Vel_real_total_SENO = out.flc_sin.signals(2).values;

u_total_SENO = out.flc_sin.signals(1).values;


figure(3)
plot(t_total_SENO,u_total_SENO,'g')
hold on
plot( t_total_SENO, Vel_real_total_SENO,'b')
title('FLC Sinusoide');
xlabel('t (s)');
ylabel('x (mm)');
legend('Desejado', 'Real')
hold off

% % Assuming vdes is the input and vr is the output
% input_signal_SENO = double(u_total_SENO);
% output_signal_SENO = double(Vel_real_total_SENO);
% 
% % Transpose the input and output signals
% input_signal_SENO = input_signal_SENO';
% output_signal_SENO = output_signal_SENO';
% 
% % Create iddata object
% data_SENO = iddata(output_signal_SENO, input_signal_SENO);
% 
% 
% real_SENO = tfest(data_SENO, 2, 2); 
% 
% % Display the estimated transfer function
% disp('Estimated Transfer Function:');
% disp(real_SENO);
% 
% 
% figure(4)
% compare(data_SENO, real_SENO);
% 
% sys_SENO=tf(real_SENO);
%% CALCULO PARA RAMPA

clc

t_total_RAMPA = out.flc_rampa.time;
Vel_real_total_RAMPA = out.flc_rampa.signals(2).values;

u_total_RAMPA = out.flc_rampa.signals(1).values;

figure(5)
plot(t_total_RAMPA,u_total_RAMPA,'g')
hold on
plot( t_total_RAMPA, Vel_real_total_RAMPA, 'b')
title('FLC Rampa');
xlabel('t (s)');
ylabel('x (mm)');
legend('Desejado', 'Real')
hold off

% % Assuming vdes is the input and vr is the output
% input_signal_RAMPA = double(u_total_RAMPA);
% output_signal_RAMPA = double(Vel_real_total_RAMPA);
% 
% % Transpose the input and output signals
% input_signal_RAMPA = input_signal_RAMPA';
% output_signal_RAMPA = output_signal_RAMPA';
% 
% % Create iddata object
% data_RAMPA = iddata(output_signal_RAMPA, input_signal_RAMPA);
% 
% 
% real_RAMPA = tfest(data_RAMPA, 2, 2); 
% 
% % Display the estimated transfer function
% disp('Estimated Transfer Function:');
% disp(real_RAMPA);
% 
% 
% figure(6)
% compare(data_RAMPA, real_RAMPA);
% 
% sys_RAMPA=tf(real_RAMPA);


%%-------------------------------------------------------------------%%
%%-------------------------------------------------------------------%%






