%% PID Sin
figure(1)
plot(out.pid_sin.time,out.pid_sin.signals(1).values, 'g');
hold on
plot(out.pid_sin.time,out.pid_sin.signals(2).values, 'b');
title('PID Sinusoide');
xlabel('t (s)');
ylabel('x (mm)');
legend('Desejado', 'Real')
hold off

%% PID Step
figure(2)
plot(out.pid_step.time,out.pid_step.signals(1).values, 'g');
hold on
plot(out.pid_step.time,out.pid_step.signals(2).values, 'b');
title('PID Degrau');
xlabel('t (s)');
ylabel('x (mm)');
legend('Desejado', 'Real')
hold off
%% PID Rampa
figure(3)
plot(out.pid_rampa.time,out.pid_rampa.signals(1).values, 'g');
hold on
plot(out.pid_rampa.time,out.pid_rampa.signals(2).values, 'b');
title('PID Rampa');
xlabel('t (s)');
ylabel('x (mm)');
legend('Desejado', 'Real')
hold off