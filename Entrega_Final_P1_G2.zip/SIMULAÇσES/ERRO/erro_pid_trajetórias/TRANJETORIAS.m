load('Test100.mat')
load('GRAV_STEP.mat')
load ('GRAV_SENO.mat')
load('GRAV_RAMPA.mat')
load('GRAV_NP.mat')

%% CALCULO PARA STEP

clc

t_total_STEP = GRAV_STEP.X.Data;
Vel_real_total_STEP = GRAV_STEP.Y(2).Data;

u_total_STEP = GRAV_STEP.Y(4).Data;

figure(1)
plot(t_total_STEP,u_total_STEP)
hold on
plot( t_total_STEP, Vel_real_total_STEP)
hold off

% t = t_total_STEP(265000:290000)- t_total_STEP(265000);
% Vel_real_STEP = Vel_real_total_STEP(265000:290000);
% u = u_total_STEP(265000:290000);
% 
% figure(3)
% plot(t,u)
% hold on
% plot(t,Vel_real_STEP)

% Assuming vdes is the input and vr is the output
input_signal_STEP = double(u_total_STEP);
output_signal_STEP = double(Vel_real_total_STEP);

% Transpose the input and output signals
input_signal_STEP = input_signal_STEP';
output_signal_STEP = output_signal_STEP';

% Create iddata object
data_STEP = iddata(output_signal_STEP, input_signal_STEP);


real_STEP = tfest(data_STEP, 2, 2); 

% Display the estimated transfer function
disp('Estimated Transfer Function:');
disp(real_STEP);


figure(2)
compare(data_STEP, real_STEP);

sys_STEP=tf(real_STEP);
%% CALCULO PARA SENO

clc

t_total_SENO = GRAV_SENO.X.Data;
Vel_real_total_SENO = GRAV_SENO.Y(2).Data;

u_total_SENO = GRAV_SENO.Y(4).Data;

figure(3)
plot(t_total_SENO,u_total_SENO)
hold on
plot( t_total_SENO, Vel_real_total_SENO)
hold off

% Assuming vdes is the input and vr is the output
input_signal_SENO = double(u_total_SENO);
output_signal_SENO = double(Vel_real_total_SENO);

% Transpose the input and output signals
input_signal_SENO = input_signal_SENO';
output_signal_SENO = output_signal_SENO';

% Create iddata object
data_SENO = iddata(output_signal_SENO, input_signal_SENO);


real_SENO = tfest(data_SENO, 2, 2); 

% Display the estimated transfer function
disp('Estimated Transfer Function:');
disp(real_SENO);


figure(4)
compare(data_SENO, real_SENO);

sys_SENO=tf(real_SENO);
%% CALCULO PARA RAMPA

clc

t_total_RAMPA = GRAV_RAMPA.X.Data;
Vel_real_total_RAMPA = GRAV_RAMPA.Y(2).Data;

u_total_RAMPA = GRAV_RAMPA.Y(4).Data;

figure(5)
plot(t_total_RAMPA,u_total_RAMPA)
hold on
plot( t_total_RAMPA, Vel_real_total_RAMPA)

% Assuming vdes is the input and vr is the output
input_signal_RAMPA = double(u_total_RAMPA);
output_signal_RAMPA = double(Vel_real_total_RAMPA);

% Transpose the input and output signals
input_signal_RAMPA = input_signal_RAMPA';
output_signal_RAMPA = output_signal_RAMPA';

% Create iddata object
data_RAMPA = iddata(output_signal_RAMPA, input_signal_RAMPA);


real_RAMPA = tfest(data_RAMPA, 2, 2); 

% Display the estimated transfer function
disp('Estimated Transfer Function:');
disp(real_RAMPA);


figure(6)
compare(data_RAMPA, real_RAMPA);

sys_RAMPA=tf(real_RAMPA);

%% CALCULO PARA NP

clc

t_total_NP = GRAV_NP.X.Data;
Vel_real_total_NP = GRAV_NP.Y(2).Data;

u_total_NP = GRAV_NP.Y(4).Data;

figure(4)
plot(t_total_NP,u_total_NP)
hold on
plot( t_total_NP, Vel_real_total_NP)


% Assuming vdes is the input and vr is the output
input_signal_NP = double(u_total_NP);
output_signal_NP = double(Vel_real_total_NP);

% Transpose the input and output signals
input_signal_NP = input_signal_NP';
output_signal_NP = output_signal_NP';

% Create iddata object
data_NP = iddata(output_signal_NP, input_signal_NP);

% Choose an appropriate system identification method, e.g., ARX, BJ, TFest, etc.
real_NP = tfest(data_NP, 2, 2); % Example using TFest

% Display the estimated transfer function
disp('Estimated Transfer Function:');
disp(real_NP);


figure(6)
compare(data_NP, real_NP);

sys2=tf(real_NP);

%%-------------------------------------------------------------------%%
%%-------------------------------------------------------------------%%


%% Identificação da planta - optimização local
% global T_STEP U_STEP VEL_REAL_STEP;
% 
% T_STEP = t_total_STEP;
% U_STEP = u_total_STEP;
% VEL_REAL_STEP = Vel_real_total_STEP;
% 
% 
% parameters(1) = 15;
% parameters(2) = 15;
% parameters(3) = 1; 
% 
% options = optimset('Display','iter', 'MaxIter', 2^16,'TolFun',1e-6, 'TolX',1e-6,'MaxFunEvals',2^16);
% [polos,MSE] = fminsearch(@F_minimizacao_STEP,parameters,options);
% 
% %----------------------------------------------%
% 
% p1 = polos(1);
% p2 = polos(2);
% K = polos(3); 
% 
% s = tf('s');
% TF = K/((s+p1)*(s+p2));
% 
% 
% Vel_opt_STEP = lsim(TF,U_STEP,T_STEP);
% 
% figure(5)
% plot (U_STEP,VEL_REAL_STEP)
% hold on
% plot(T_STEP,Vel_opt_STEP)

% erro = Vel_real_total_STEP - u_total_STEP;
% mse = mean((erro));

% erro_STEP = (Vel_real_total_STEP - u_total_STEP)/u_total_STEP;
% erro_STEP2 = erro_STEP^2;
% erro_STEP3 = sqrt(erro_STEP2);
% erro_per_STEP = erro_STEP3 * 100;
% mse = mean((erro_STEP3).^2);

%-----------------------------------------------------------%

% erro_SENO = (Vel_real_total_SENO - u_total_SENO)/u_total_SENO;
% erro_SENO2 = erro^2;
% erro_SENO3 = sqrt(erro2);
% erro_per_SENO = erro_SENO3 * 100;
% mse = mean((erro_SENO).^2);
% 

%% ERRO STEP

RSS_STEP = sum((Vel_real_total_STEP - u_total_STEP).^2);
magni_vel_real_STEP = sum(Vel_real_total_STEP.^2);
erro_per_STEP = (RSS_STEP/magni_vel_real_STEP)*100;

%% ERRO SENO

RSS_SENO = sum((Vel_real_total_SENO - u_total_SENO).^2);
magni_vel_real_SENO = sum(Vel_real_total_SENO.^2);
erro_per_SENO = (RSS_SENO/magni_vel_real_SENO)*100;

%% ERRO RAMPA

RSS_RAMPA = sum((Vel_real_total_RAMPA - u_total_RAMPA).^2);
magni_vel_real_RAMPA = sum(Vel_real_total_RAMPA.^2);
erro_per_RAMPA = (RSS_RAMPA/magni_vel_real_RAMPA)*100;

%% ERRO NP

RSS_NP = sum((Vel_real_total_NP - u_total_NP).^2);
magni_vel_real_NP = sum(Vel_real_total_NP.^2);
erro_per_NP = (RSS_NP/magni_vel_real_NP)*100;






